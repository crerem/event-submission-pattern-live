def lambda_handler(event, context):
    # implement data processing

    return {
        'statusCode': 200,
        'body': event
    }
